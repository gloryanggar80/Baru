package com.gloryanggar.odysseus;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraImageUri;
    private static final int PERM = 100;

    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), r -> {
            if (filePathCallback == null) return;
            Uri[] res = null;
            if (r.getResultCode() == RESULT_OK && r.getData() != null && r.getData().getDataString() != null)
                res = new Uri[]{Uri.parse(r.getData().getDataString())};
            filePathCallback.onReceiveValue(res);
            filePathCallback = null;
        });

    private final ActivityResultLauncher<Uri> cam = registerForActivityResult(
        new ActivityResultContracts.TakePicture(), ok -> {
            if (filePathCallback == null) return;
            filePathCallback.onReceiveValue(ok && cameraImageUri != null ? new Uri[]{cameraImageUri} : null);
            filePathCallback = null;
        });

    @SuppressLint({"SetJavaScriptEnabled"})
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) getSupportActionBar().hide();
        mintaIzin();
        webView = findViewById(R.id.webView);
        aturWV();
        webView.loadDataWithBaseURL("http://localhost/", baca("index.html"), "text/html", "UTF-8", null);
        webView.setDownloadListener((url, ua, cd, mt, cl) -> {
            try {
                DownloadManager.Request q = new DownloadManager.Request(Uri.parse(url));
                q.setMimeType(mt);
                String ck = CookieManager.getInstance().getCookie(url);
                q.addRequestHeader("Cookie", ck);
                q.addRequestHeader("User-Agent", ua);
                q.setTitle(URLUtil.guessFileName(url, cd, mt));
                q.setDescription("Data AI Odysseus");
                q.allowScanningByMediaScanner();
                q.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                q.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mt));
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(q);
                Toast.makeText(this, "✅ Tersimpan di Download", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Gagal: "+e.getMessage(), Toast.LENGTH_SHORT).show(); }
        });
    }

    private void aturWV() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " AI-ODYSSEUS-APP");
        s.setDatabasePath(getApplicationContext().getDir("database", MODE_PRIVATE).getPath());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u) { v.loadUrl(u); return true; }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                filePathCallback = cb;
                Intent g = new Intent(Intent.ACTION_GET_CONTENT);
                g.addCategory(Intent.CATEGORY_OPENABLE);
                g.setType("image/*");
                Intent k = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                try {
                    File ff = buatFoto();
                    cameraImageUri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", ff);
                    k.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
                } catch (IOException e) { cameraImageUri = null; }
                Intent c = Intent.createChooser(g, "Pilih Foto");
                c.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{k});
                picker.launch(c);
                return true;
            }
        });
    }

    private File buatFoto() throws IOException {
        String t = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        return File.createTempFile("ODYSSEUS_"+t, ".jpg", getExternalFilesDir(Environment.DIRECTORY_PICTURES));
    }

    private String baca(String n) {
        try {
            java.io.InputStream i = getAssets().open(n);
            byte[] buf = new byte[i.available()];
            i.read(buf); i.close();
            return new String(buf);
        } catch (IOException e) { return "ERROR: index.html tidak ditemukan"; }
    }

    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }

    private void mintaIzin() {
        String[] iz = Build.VERSION.SDK_INT >= 33
            ? new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES}
            : new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
        boolean perlu = false;
        for (String x : iz) if (ContextCompat.checkSelfPermission(this, x) != PackageManager.PERMISSION_GRANTED) { perlu = true; break; }
        if (perlu) ActivityCompat.requestPermissions(this, iz, PERM);
    }

    @Override public void onRequestPermissionsResult(int c, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        if (c == PERM) for (int x : r) if (x != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "⚠️ Upload foto mungkin tidak jalan", Toast.LENGTH_LONG).show(); break;
        }
    }

    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}